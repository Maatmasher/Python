def get_all_nodes(
    self, max_retries: int = MAX_RETRIES_DEFAULT
) -> Dict[str, Dict[str, Optional[str]]]:
    """Получить состояние всех узлов с Centrum по частям из файла node_list.txt или из БД"""

    # Определяем источник данных
    node_list_path = Path(FILES_DIR) / "node_list.txt"
    use_database = not node_list_path.exists()

    if use_database:
        logger.info("Файл node_list.txt не найден. Получение данных из базы PostgreSQL")

        # Получаем данные из БД
        db_result = self._get_nodes_from_database()
        if "error" in db_result:
            logger.error(f"Ошибка получения данных из БД: {db_result['error']}")
            return db_result

        logger.info(f"Получено {len(db_result)} узлов из базы данных")

        # Сохраняем результат и возвращаем
        self.node_result = db_result
        return db_result

    else:
        logger.info("Получение состояния всех узлов с Centrum из файла node_list.txt")

        # Существующая логика для работы с файлом
        # Читаем все номера серверов
        with open(node_list_path, "r", encoding="utf-8") as f:
            all_nodes = [line.strip() for line in f if line.strip()]

        if not all_nodes:
            logger.warning("Файл node_list.txt пуст")
            return {}

        logger.info(f"Найдено {len(all_nodes)} узлов в файле node_list.txt")

        # Разбиваем на группы по 10 серверов
        all_results: Dict[str, Dict[str, Optional[str]]] = {}
        chunk_size = 10

        for i in range(0, len(all_nodes), chunk_size):
            chunk = all_nodes[i : i + chunk_size]
            logger.info(
                f"Обработка группы {i//chunk_size + 1}/{(len(all_nodes)-1)//chunk_size + 1}: {chunk}"
            )

            # Записываем текущую группу в server.txt
            server_list_path = self.config_dir / FILES["server_list"]
            with open(server_list_path, "w", encoding="utf-8") as f:
                f.write("\n".join(chunk))

            # Получаем состояние для текущей группы
            for _ in range(max_retries):
                chunk_result = self.get_nodes_from_file()

                # Проверяем на ошибки
                if "error" in chunk_result:
                    logger.error(
                        f"Ошибка при получении состояния для группы {chunk}: {chunk_result['error']}"
                    )
                    # Продолжаем с следующей группой, но записываем ошибку
                    for node in chunk:
                        all_results[node] = {
                            "tp": node,
                            "status": "ERROR",
                            "message": f"Ошибка получения состояния: {chunk_result['error'].get('message', 'Unknown error')}",
                            "type": None,
                            "cv": None,
                            "pv": None,
                            "online": None,
                            "ip": None,
                            "ut": None,
                            "local patches": None,
                        }
                else:
                    # Добавляем результаты текущей группы
                    all_results.update(chunk_result)

            # Пауза 3 секунды между группами
            if i + chunk_size < len(all_nodes):  # Не ждем после последней группы
                logger.info("Ожидание 3 секунды перед следующей группой...")
                time.sleep(3)

        # Фильтрация по типу (аналогично БД)
        all_results = {
            ip: node_data
            for ip, node_data in all_results.items()
            if node_data.get("type") is not None
        }

        logger.info(
            f"Все группы обработаны. Всего получено состояний: {len(all_results)}"
        )

        # Сохраняем объединенный результат
        self.node_result = all_results
        return all_results
