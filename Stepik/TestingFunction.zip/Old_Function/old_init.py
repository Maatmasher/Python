def __init__(
    self,
    centrum_host: str = CENTRUM_HOST,
    config_dir: str = CONFIG_DIR,
    jar_name: str = JAR_NAME,
    target_version: str = TARGET_VERSION,
    part_server_size: int = part_server_SIZE,
    max_iterations: Optional[int] = MAX_ITERATIONS,
    service_name: str = "UnifiedServerUpdater",
):
    logger.debug("Инициализация UnifiedServerUpdater")
    logger.debug(
        f"Параметры: centrum_host={centrum_host}, config_dir={config_dir}, "
        f"jar_name={jar_name}, target_version={target_version}, "
        f"part_server_size={part_server_size}, max_iterations={max_iterations}"
    )

    # Параметры из ConfiguratorTool
    self.centrum_host = centrum_host
    self.config_dir = Path(config_dir)
    self.jar_path = self.config_dir / jar_name
    self.node_result: Dict[str, Dict[str, Optional[str]]] = {}
    self.work_tp: List[str] = []
    self.error_tp: List[str] = []
    self.update_tp: List[str] = []
    self.ccm_tp: List[str] = []
    self.unzip_tp: List[str] = []
    self.no_update_needed_tp: List[str] = []
    self.unavailable: List[str] = []

    # Параметры из ServerUpdater
    self.target_version = target_version
    self.part_server_size = part_server_size
    self.max_iterations = max_iterations
    self.current_iteration = 0
    self.updated_servers: Set[str] = set()

    # Параметры для подключения к PostgreSQL
    self.db_password = None  # Будет инициализирован при первом обращении к БД

    # Параметры из ServiceRestarter
    self.user = SSH_USER
    self.plink_path = Path(PLINK_PATH)
    self.service_name = service_name
    self.password = self._init_password()

    logging.debug(f"Конфигурация: plink_path={self.plink_path}, user={self.user}")

    if not self.jar_path.exists():
        error_msg = f"JAR файл не найден: {self.jar_path}"
        logger.error(error_msg)
        raise FileNotFoundError(error_msg)

    logger.info("UnifiedServerUpdater успешно инициализирован")
