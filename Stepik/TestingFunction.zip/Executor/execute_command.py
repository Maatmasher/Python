import subprocess
import time
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Union

from logger_manager import LoggerManager

MAX_RETRIES_SINGLE = 3


class CommandExecutor:
    """Класс для выполнения команд с повторами и обработкой результатов"""

    def __init__(self, logger_manager: LoggerManager):
        self.logger = logger_manager.get_logger(__name__)
        self.logger.info("CommandExecutor инициализирован")

    def execute_jar_command(
        self,
        jar_path: Path,
        args: List[str],
        max_retries: int = MAX_RETRIES_SINGLE,
        wait_between_retries: int = 3,
    ) -> Dict[str, Dict[str, Optional[str]]]:
        """Выполняет команду JAR с повторами для недоступных узлов"""
        self.logger.debug(f"Выполнение команды: args={args}, max_retries={max_retries}")

        result_dict: Dict[str, Dict[str, Optional[str]]] = {}
        unavailable_nodes: Set[str] = set()
        success_nodes: Set[str] = set()
        no_update_needed_nodes: Set[str] = set()
        attempt = 0

        while attempt < max_retries:
            attempt += 1
            if max_retries > 1:
                self.logger.info(f"Попытка {attempt} из {max_retries}")

            try:
                self.logger.debug(
                    f"Запуск subprocess.run с командой: java -jar {jar_path} {' '.join(args)}"
                )

                result = subprocess.run(
                    ["java", "-jar", str(jar_path)] + args,
                    check=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    encoding="cp1251",
                    errors="replace",
                )

                if not result.stdout:
                    self.logger.warning("Пустой вывод от команды")
                    continue

                self.logger.debug(
                    f"Получен вывод команды (первые 200 символов): {result.stdout[:200]}..."
                )

                (
                    current_result,
                    current_unavailable,
                    current_success,
                    current_no_update,
                ) = self._parse_output(result.stdout)

                self.logger.debug(
                    f"Результат парсинга: nodes={len(current_result)}, unavailable={len(current_unavailable)}, "
                    f"success={len(current_success)}, no_update={len(current_no_update)}"
                )

                result_dict.update(current_result)
                unavailable_nodes.update(current_unavailable)
                success_nodes.update(current_success)
                no_update_needed_nodes.update(current_no_update)

                if not current_unavailable or max_retries <= 1:
                    self.logger.debug(
                        "Нет недоступных узлов или max_retries <= 1, завершаем попытки"
                    )
                    break

                if attempt < max_retries:
                    self.logger.debug(
                        f"Ожидание {wait_between_retries} секунд перед следующей попыткой"
                    )
                    time.sleep(wait_between_retries)

            except subprocess.CalledProcessError as e:
                error_msg = e.stderr if e.stderr else str(e)
                self.logger.error(f"Ошибка выполнения команды: {error_msg}")
                if attempt == max_retries or max_retries <= 1:
                    self.logger.error(
                        "Достигнуто максимальное количество попыток, возвращаем ошибку"
                    )
                    return {"error": {"message": error_msg}}
                continue
            except Exception as e:
                self.logger.error(f"Неожиданная ошибка: {str(e)}", exc_info=True)
                if attempt == max_retries or max_retries <= 1:
                    self.logger.error(
                        "Достигнуто максимальное количество попыток, возвращаем ошибку"
                    )
                    return {"error": {"message": str(e)}}
                continue

        # Заполнение недоступных узлов
        for node in unavailable_nodes:
            self.logger.debug(f"Добавление недоступного узла: {node}")
            result_dict[node] = {
                "tp": node,
                "type": None,
                "cv": None,
                "pv": None,
                "online": None,
                "status": "UNAVAILABLE",
                "ip": None,
                "ut": None,
                "local patches": None,
            }

        # Заполнение успешных узлов
        for node in success_nodes:
            if node not in result_dict:
                self.logger.debug(f"Добавление успешного узла: {node}")
                result_dict[node] = {
                    "tp": node,
                    "status": "SUCCESS",
                    "message": "успешно запланировано",
                    "type": None,
                    "cv": None,
                    "pv": None,
                    "online": None,
                    "ip": None,
                    "ut": None,
                    "local patches": None,
                }

        # Заполнение узлов, не требующих обновления
        for node in no_update_needed_nodes:
            if node not in result_dict:
                self.logger.debug(f"Добавление узла, не требующего обновления: {node}")
                result_dict[node] = {
                    "tp": node,
                    "status": "NO_UPDATE_NEEDED",
                    "message": f"Обновление узла {node} не требуется",
                    "type": None,
                    "cv": None,
                    "pv": None,
                    "online": None,
                    "ip": None,
                    "ut": None,
                    "local patches": None,
                }

        self.logger.info(
            f"Команда выполнена. Всего узлов: {len(result_dict)}, "
            f"успешных: {len(success_nodes)}, недоступных: {len(unavailable_nodes)}, "
            f"не требующих обновления: {len(no_update_needed_nodes)}"
        )

        return result_dict

    def _parse_output(
        self, output: str
    ) -> Tuple[Dict[str, Dict[str, Optional[str]]], Set[str], Set[str], Set[str]]:
        """Парсим весь вывод stdout из JAR"""
        self.logger.debug("Начало парсинга вывода команды")

        if not output:
            self.logger.warning("Пустой вывод для парсинга")
            return {}, set(), set(), set()

        devices_dict: Dict[str, Dict[str, Optional[str]]] = {}
        unavailable_nodes: Set[str] = set()
        success_nodes: Set[str] = set()
        no_update_needed_nodes: Set[str] = set()

        try:
            self.logger.debug("Парсинг строк вывода для статусов обновления")
            for line in output.splitlines():
                line = line.strip()
                self.logger.debug(f"Обработка строки: {line}")

                # Обработка успешных узлов
                if "успешно запланировано" in line:
                    self.logger.debug(f"Найдена строка успешного обновления: {line}")
                    for part in line.split():
                        if (
                            part.replace(".", "").isdigit()
                            and len(part.split(".")) >= 3
                        ):
                            self.logger.debug(f"Добавление успешного узла: {part}")
                            success_nodes.add(part)
                            devices_dict[part] = {
                                "tp": part,
                                "status": "SUCCESS",
                                "message": f"Обновление узла {part} успешно запланировано",
                                "type": None,
                                "cv": None,
                                "pv": None,
                                "online": None,
                                "ip": None,
                                "ut": None,
                                "local patches": None,
                            }

                # Обработка недоступных узлов
                elif "недоступен" in line:
                    self.logger.debug(f"Найдена строка недоступного узла: {line}")
                    for part in line.split():
                        if (
                            part.replace(".", "").isdigit()
                            and len(part.split(".")) >= 3
                        ):
                            self.logger.debug(f"Добавление недоступного узла: {part}")
                            unavailable_nodes.add(part)
                            devices_dict[part] = {
                                "tp": part,
                                "status": "UNAVAILABLE",
                                "message": f"Узел {part} недоступен",
                                "type": None,
                                "cv": None,
                                "pv": None,
                                "online": None,
                                "ip": None,
                                "ut": None,
                                "local patches": None,
                            }

                # Обработка узлов, не требующих обновления
                elif "не требуется" in line:
                    self.logger.debug(
                        f"Найдена строка узла, не требующего обновления: {line}"
                    )
                    for part in line.split():
                        if (
                            part.replace(".", "").isdigit()
                            and len(part.split(".")) >= 3
                        ):
                            self.logger.debug(
                                f"Добавление узла, не требующего обновления: {part}"
                            )
                            no_update_needed_nodes.add(part)
                            devices_dict[part] = {
                                "tp": part,
                                "status": "NO_UPDATE_NEEDED",
                                "message": f"Обновление узла {part} не требуется",
                                "type": None,
                                "cv": None,
                                "pv": None,
                                "online": None,
                                "ip": None,
                                "ut": None,
                                "local patches": None,
                            }

            self.logger.debug("Парсинг строк вывода для детальной информации об узлах")
            for line in output.splitlines():
                line = line.strip()
                self.logger.debug(f"Обработка строки данных: {line}")

                if not line or line.startswith(("Current client version:", "-")):
                    continue

                device: Dict[str, Optional[str]] = {}
                device_key = None
                tp_value = None

                # Разбор по символу ";"
                for pair in line.split(";"):
                    pair = pair.strip()
                    if "=" in pair:
                        key, value = pair.split("=", 1)
                        key = key.strip()
                        value = (
                            value.strip() if value.strip().lower() != "null" else None
                        )
                        device[key] = value

                        if key == "ip" and value:
                            device_key = value
                        elif key == "tp" and value:
                            tp_value = value
                            if not device_key:
                                device_key = value

                if not device_key and tp_value:
                    device_key = tp_value

                if device and device_key:
                    self.logger.debug(
                        f"Добавление/обновление узла {device_key}: {device}"
                    )
                    devices_dict[device_key] = device

                    status = (device.get("status") or "").upper()
                    online = (device.get("online") or "").upper()

                    if status == "UNAVAILABLE" or online == "FALSE" or online == "NO":
                        self.logger.debug(
                            f"Узел {device_key} недоступен (status={status}, online={online})"
                        )
                        unavailable_nodes.add(device_key)

        except Exception as e:
            self.logger.error(f"Ошибка при парсинге вывода: {str(e)}", exc_info=True)
            return {}, set(), set(), set()

        self.logger.info(
            f"Парсинг завершен. Узлов: {len(devices_dict)}, "
            f"недоступных: {len(unavailable_nodes)}, "
            f"успешных: {len(success_nodes)}, "
            f"не требующих обновления: {len(no_update_needed_nodes)}"
        )

        return devices_dict, unavailable_nodes, success_nodes, no_update_needed_nodes
