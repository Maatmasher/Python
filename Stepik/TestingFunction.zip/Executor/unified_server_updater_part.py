import time
import subprocess
from pathlib import Path
from typing import List, Dict, Optional, Set, Tuple, Union
import json
import keyring
from getpass import getpass
import psycopg2
from psycopg2.extras import DictCursor
from psycopg2 import sql

from config_manager import ConfigManager
from logger_manager import LoggerManager, create_logger_manager
from execute_command import CommandExecutor  # Добавлен импорт


# ==================== КОНФИГУРАЦИОННЫЕ ПАРАМЕТРЫ ====================

MAX_RETRIES_DEFAULT = 3
MAX_RETRIES_SINGLE = 3
DEFAULT_NO_BACKUP = True

# ====================================================================


class UnifiedServerUpdater:
    """Унифицированный класс для работы с JAR-инструментом конфигурации и пошаговым обновлением серверов"""

    def __init__(
        self,
        config: Optional[ConfigManager] = None,
        logger_manager: Optional[LoggerManager] = None,
    ):
        # Инициализация конфигурации
        self.config = config or ConfigManager()
        self.current_iteration = 0

        # Инициализация логирования
        self.logger_manager = logger_manager or create_logger_manager()
        self.logger = self.logger_manager.get_logger(__name__)

        # Инициализация исполнителя команд
        self.command_executor = CommandExecutor(self.logger_manager)

        # Валидация конфигурации
        if not self.config.validate():
            self.logger.error("Невалидная конфигурация")
            raise ValueError("Невалидная конфигурация")

        self.logger.info("UnifiedServerUpdater инициализирован")

        # Инициализация остальных компонентов
        self._init_components()

    def _init_components(self):
        """Инициализация компонентов на основе конфигурации"""
        # Пример использования конфигурации
        self.updated_servers: Set[str] = set()
        self.password = self._init_password()
        self.service_name = self.config.get("service_name")
        self.centrum_host = self.config.get("centrum_host")
        self.target_version = self.config.get("target_version")
        self.jar_path = Path(self.config.get("config_dir")) / self.config.get(
            "jar_name"
        )

        # Проверка существования JAR файла
        if not self.jar_path.exists():
            error_msg = f"JAR файл не найден: {self.jar_path}"
            self.logger.error(error_msg)
            raise FileNotFoundError(error_msg)

        self.logger.debug(f"JAR путь: {self.jar_path}")

    # ... остальные методы остаются без изменений ...

    def _execute_command(
        self, args: List[str], max_retries: int = MAX_RETRIES_SINGLE
    ) -> Dict[str, Dict[str, Optional[str]]]:
        """Выполняет команду с повторами для недоступных узлов"""
        return self.command_executor.execute_jar_command(
            self.jar_path, args, max_retries, self.config.get("wait_between_retries")
        )

    # ... остальные методы остаются без изменений ...
