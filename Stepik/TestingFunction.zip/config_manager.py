# config_manager.py
import os
from pathlib import Path
from typing import Dict, Any, Optional
import logging


class ConfigManager:
    """Класс для управления конфигурационными параметрами"""

    def __init__(self, config_file: Optional[str] = None):
        self._config: Dict[str, Any] = {}
        self._load_default_config()

        if config_file:
            self.load_from_file(config_file)

    def _load_default_config(self) -> None:
        """Загрузка конфигурации по умолчанию"""
        CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

        self._config = {
            # Основные настройки
            "centrum_host": "10.21.11.45",
            # "current_dir": CURRENT_DIR,
            "config_dir": os.path.join(CURRENT_DIR, "updaterJar"),
            "jar_name": "ConfiguratorCmdClient-1.5.1.jar",
            # "files_dir": os.path.join(CURRENT_DIR, "Files"),
            # "plink_dir": os.path.join(CURRENT_DIR, "Plink"),
            "ssh_user": "otis",
            "service_name": "UnifiedServerUpdater",
            "plink_path": os.path.join(CURRENT_DIR, "Plink", "plink.exe"),
            # Настройки подключения к БД
            "db_host": "10.21.11.201",
            "db_port": 5432,
            "db_name": "GD",
            "db_user": "postgres",
            "db_table": "tpl_muk",
            "db_service_name": "rn-otis-tools",
            # Настройки обновления
            "target_version": "10.4.17.15",
            "part_server_size": 2,
            "max_iterations": 1,
            # "max_retries_default": 3,
            # "max_retries_single": 3,
            # "default_no_backup": True,
            "pre_update_work": True,
            "post_update_work": True,
            # Таймауты и интервалы
            "wait_between_retries": 3,
            "status_check_interval": 300,
            "ping_timeout": 2000,
            "plink_timeout": 300,
            "pre_update_timeout": 60,
            "post_update_timeout": 60,
            # Имена файлов
            "status_prefix": "server_",
            "files": {
                "server_list": "server.txt",
                "node_list": os.path.join("Files", "node_list.txt"),
                "node_result": os.path.join("Files", "node_result.json"),
                "ccm_restart_commands": os.path.join("Plink", "ccm_commands.txt"),
                "unzip_restart_commands": os.path.join("Plink", "unzip_commands.txt"),
                "pre_update_commands": os.path.join("Plink", "pre_update_commands.txt"),
                "post_update_commands": os.path.join(
                    "Plink", "post_update_commands.txt"
                ),
                "work_tp": "work_tp.txt",
                "error_tp": "error_tp.txt",
                "update_tp": "update_tp.txt",
                "ccm_tp": "ccm_tp.txt",
                "unzip_tp": "unzip_tp.txt",
                "no_update_needed_tp": "no_update_needed_tp.txt",
                "unavailable_tp": "unavailable_tp.txt",
            },
        }

    def load_from_file(self, config_file: str) -> None:
        """Загрузка конфигурации из JSON файла"""
        try:
            import json

            with open(config_file, "r", encoding="utf-8") as f:
                file_config = json.load(f)
                self._config.update(file_config)
            logging.info(f"Конфигурация загружена из файла: {config_file}")
        except Exception as e:
            logging.warning(f"Не удалось загрузить конфигурацию из файла: {e}")

    def save_to_file(self, config_file: str) -> None:
        """Сохранение конфигурации в JSON файл"""
        try:
            import json

            with open(config_file, "w", encoding="utf-8") as f:
                json.dump(self._config, f, indent=2, ensure_ascii=False)
            logging.info(f"Конфигурация сохранена в файл: {config_file}")
        except Exception as e:
            logging.error(f"Ошибка сохранения конфигурации: {e}")

    def get(self, key: str, default: Any = None) -> Any:
        """Получение значения конфигурации"""
        try:
            # Поддержка вложенных ключей через точку
            if "." in key:
                keys = key.split(".")
                value = self._config
                for k in keys:
                    value = value[k]
                return value
            return self._config.get(key, default)
        except (KeyError, TypeError):
            return default

    def set(self, key: str, value: Any) -> None:
        """Установка значения конфигурации"""
        if "." in key:
            keys = key.split(".")
            config_level = self._config
            for k in keys[:-1]:
                if k not in config_level:
                    config_level[k] = {}
                config_level = config_level[k]
            config_level[keys[-1]] = value
        else:
            self._config[key] = value

    def get_full_path(self, file_key: str) -> Path:
        """Получение полного пути к файлу"""
        file_name = self.get(f"files.{file_key}")
        base_dir = self.get("config_dir")
        return Path(base_dir) / file_name

    def validate(self) -> bool:
        """Валидация конфигурации"""
        required_paths = ["config_dir", "plink_path", "files.server_list"]

        for path_key in required_paths:
            path = (
                self.get_full_path(path_key)
                if path_key.startswith("files.")
                else Path(self.get(path_key))
            )
            if not path.exists():
                logging.error(f"Путь не существует: {path}")
                return False

        return True

    def __getitem__(self, key: str) -> Any:
        """Доступ к конфигурации через квадратные скобки"""
        return self.get(key)

    def __setitem__(self, key: str, value: Any) -> None:
        """Установка конфигурации через квадратные скобки"""
        self.set(key, value)

    def __contains__(self, key: str) -> bool:
        """Проверка наличия ключа в конфигурации"""
        try:
            self.get(key)
            return True
        except (KeyError, TypeError):
            return False

    @property
    def all_config(self) -> Dict[str, Any]:
        """Получение всей конфигурации (только для чтения)"""
        return self._config.copy()
