import time
import subprocess
from pathlib import Path
from typing import List, Dict, Optional, Set, Tuple, Union
import json
import keyring
from getpass import getpass
import psycopg2
from psycopg2.extras import DictCursor
from psycopg2 import sql

from config_manager import ConfigManager
from logger_manager import LoggerManager, create_logger_manager


# ==================== КОНФИГУРАЦИОННЫЕ ПАРАМЕТРЫ ====================

MAX_RETRIES_DEFAULT = 3
MAX_RETRIES_SINGLE = 3
DEFAULT_NO_BACKUP = True

# ====================================================================


class UnifiedServerUpdater:
    """Унифицированный класс для работы с JAR-инструментом конфигурации и пошаговым обновлением серверов"""

    def __init__(
        self,
        config: Optional[ConfigManager] = None,
        logger_manager: Optional[LoggerManager] = None,
    ):
        # Инициализация конфигурации
        self.config = config or ConfigManager()
        self.current_iteration = 0

        # Инициализация логирования
        self.logger_manager = logger_manager or create_logger_manager()
        self.logger = self.logger_manager.get_logger(__name__)

        # Валидация конфигурации
        if not self.config.validate():
            self.logger.error("Невалидная конфигурация")
            raise ValueError("Невалидная конфигурация")

        self.logger.info("UnifiedServerUpdater инициализирован")

        # Инициализация остальных компонентов
        self._init_components()

    def _init_components(self):
        """Инициализация компонентов на основе конфигурации"""
        # Пример использования конфигурации
        self.updated_servers: Set[str] = set()
        self.password = self._init_password()
        self.service_name = self.config.get("service_name")
        self.centrum_host = self.config.get("centrum_host")
        self.target_version = self.config.get("target_version")
        self.jar_path = Path(self.config.get("config_dir")) / self.config.get(
            "jar_name"
        )

        # Проверка существования JAR файла
        if not self.jar_path.exists():
            error_msg = f"JAR файл не найден: {self.jar_path}"
            self.logger.error(error_msg)
            raise FileNotFoundError(error_msg)

        self.logger.debug(f"JAR путь: {self.jar_path}")

    def _init_db_password(self) -> str:
        """Инициализирует пароль для базы данных"""
        try:
            db_password = keyring.get_password(
                self.config.get("db_service_name"), self.config.get("db_user")
            )
            # Если пароль есть в keyring, проверяем его валидность
            if db_password is not None:
                if self._test_db_connection(db_password):
                    return db_password
                self.logger.warning(
                    "Пароль БД из keyring не подходит. Требуется ввод нового пароля."
                )

            # Если пароля нет или он невалидный — запрашиваем новый
            db_password = getpass(
                f"Введите пароль для базы данных (пользователь {self.config.get("db_user")}): "
            )

            # Проверяем новый пароль
            if self._test_db_connection(db_password):
                keyring.set_password(
                    self.config.get("db_service_name"),
                    self.config.get("db_user"),
                    db_password,
                )
                self.logger.info("Пароль БД успешно сохранён в keyring")
                return db_password
            else:
                raise ValueError("Неверный пароль для базы данных")

        except Exception as e:
            self.logger.error(f"Ошибка при работе с keyring для БД: {str(e)}")
            raise RuntimeError("Не удалось инициализировать пароль БД") from e

    def _init_password(self) -> str:
        """Инициализирует пароль, проверяя keyring или запрашивая у пользователя"""
        try:
            password = keyring.get_password(
                self.service_name, self.config.get("ssh_user")
            )
            # Если пароль есть в keyring, проверяем его валидность
            if password is not None:
                if self._test_password(password):  # Нужно реализовать метод проверки
                    return password
                self.logger.warning(
                    "Пароль из keyring не подходит. Требуется ввод нового пароля."
                )

            # Если пароля нет или он невалидный — запрашиваем новый
            password = getpass(
                f"Введите пароль для пользователя {self.config.get("ssh_user")}: "
            )
            keyring.set_password(
                self.service_name, self.config.get("ssh_user"), password
            )
            self.logger.info("Пароль успешно сохранён в keyring")
            return password
        except Exception as e:
            self.logger.error(f"Ошибка при работе с keyring: {str(e)}")
            raise RuntimeError("Не удалось инициализировать пароль") from e

    def _test_password(self, password: str) -> bool:
        """Проверяет, работает ли пароль (например, пробует подключиться)."""
        try:
            # Пример: пробуем выполнить простую команду через SSH
            test_cmd = f"plink.exe -ssh {self.config.get("ssh_user")}@{self.centrum_host} -pw {password} -batch echo OK"
            subprocess.run(
                test_cmd, check=True, shell=True, timeout=5, capture_output=True
            )
            return True
        except subprocess.CalledProcessError:
            return False
        except Exception:
            return False

    def _test_db_connection(self, password: str) -> bool:
        """Проверяет подключение к базе данных"""
        try:
            conn = psycopg2.connect(
                host=self.config.get("db_host"),
                port=self.config.get("db_port"),
                database=self.config.get("db_name"),
                user=self.config.get("db_user"),
                password=password,
                connect_timeout=5,
            )
            conn.close()
            return True
        except psycopg2.Error:
            return False
        except Exception:
            return False

    def _get_nodes_from_database(self) -> Dict[str, Dict[str, Optional[str]]]:
        """Получает информацию об узлах из базы данных PostgreSQL"""
        self.logger.info("Получение информации об узлах из базы данных PostgreSQL")

        try:
            # Получаем пароль для БД
            if not hasattr(self, "db_password") or self.db_password is None:
                self.db_password = self._init_db_password()

            # Подключаемся к базе данных
            conn = psycopg2.connect(
                host=self.config.get("db_host"),
                port=self.config.get("db_port"),
                database=self.config.get("db_name"),
                user=self.config.get("db_user"),
                password=self.db_password,
            )

            self.logger.debug(
                f"Успешное подключение к БД {self.config.get("db_name")} на {self.config.get("db_host")}:{self.config.get("db_port")}"
            )

            with conn.cursor(cursor_factory=DictCursor) as cursor:
                # Выполняем запрос для получения всех узлов
                query = sql.SQL(
                    """
                    SELECT tp, type, cv, pv, online, ip, status, ul as ut, "locPatches" as local_patches, 
                        sel_date, ins_date 
                    FROM {table}
                    WHERE type IS NOT NULL
                    ORDER BY tp
                """
                ).format(table=sql.Identifier(self.config.get("db_table")))

                self.logger.debug(f"Выполнение запроса: {query.as_string(conn)}")
                cursor.execute(query)

                rows = cursor.fetchall()
                self.logger.info(f"Получено {len(rows)} записей из базы данных")

            conn.close()

            # Конвертируем результат в нужный формат
            return self._convert_db_rows_to_nodes_format(rows)

        except psycopg2.Error as e:
            error_msg = f"Ошибка при работе с базой данных: {str(e)}"
            self.logger.error(error_msg)
            return {"error": {"message": error_msg}}
        except Exception as e:
            error_msg = f"Неожиданная ошибка при обращении к БД: {str(e)}"
            self.logger.error(error_msg, exc_info=True)
            return {"error": {"message": error_msg}}

    def _convert_db_rows_to_nodes_format(
        self, rows
    ) -> Dict[str, Dict[str, Optional[str]]]:
        """Конвертирует строки из БД в формат словаря узлов"""
        self.logger.debug(f"Конвертация {len(rows)} строк из БД в формат узлов")

        nodes_dict = {}

        for row in rows:
            try:
                # Получаем данные из строки БД
                row_data = dict(row)

                # Определяем ключ для узла (приоритет: ip, затем tp)
                node_key = row_data.get("ip") or row_data.get("tp")
                if not node_key:
                    self.logger.warning(f"Пропуск строки без ip и tp: {row_data}")
                    continue

                # Формируем словарь узла в нужном формате
                node_info = {
                    "tp": self._safe_str_convert(row_data.get("tp")),
                    "type": self._safe_str_convert(row_data.get("type")),
                    "cv": self._safe_str_convert(row_data.get("cv")),
                    "pv": self._safe_str_convert(row_data.get("pv")),
                    "online": self._safe_str_convert(row_data.get("online")),
                    "status": self._safe_str_convert(row_data.get("status")),
                    "ip": self._safe_str_convert(row_data.get("ip")),
                    "ut": self._safe_str_convert(row_data.get("ut")),
                    "local patches": self._safe_str_convert(
                        row_data.get("local_patches")
                    ),
                }

                # Добавляем узел в результирующий словарь
                nodes_dict[node_key] = node_info

                self.logger.debug(
                    f"Добавлен узел {node_key}: type={node_info['type']}, status={node_info['status']}"
                )

            except Exception as e:
                self.logger.error(f"Ошибка при обработке строки БД: {row_data}, ошибка: {str(e)}")  # type: ignore
                continue

        self.logger.info(f"Успешно сконвертировано {len(nodes_dict)} узлов из БД")
        return nodes_dict

    def _safe_str_convert(self, value) -> Optional[str]:
        """Безопасная конвертация значения в строку"""
        if value is None:
            return None
        if isinstance(value, str):
            return value.strip() if value.strip() else None
        # Для datetime объектов и других типов
        return str(value).strip() if str(value).strip() else None

    def _execute_command(
        self, args: List[str], max_retries: int = MAX_RETRIES_SINGLE
    ) -> Dict[str, Dict[str, Optional[str]]]:
        """Выполняет команду с повторами для недоступных узлов"""
        self.logger.debug(f"Выполнение команды: args={args}, max_retries={max_retries}")

        result_dict: Dict[str, Dict[str, Optional[str]]] = {}
        unavailable_nodes: Set[str] = set()
        success_nodes: Set[str] = set()
        no_update_needed_nodes: Set[str] = set()
        attempt = 0

        while attempt < max_retries:
            attempt += 1
            if max_retries > 1:
                self.logger.info(f"Попытка {attempt} из {max_retries}")

            try:
                self.logger.debug(
                    f"Запуск subprocess.run с командой: java -jar {self.jar_path} {' '.join(args)}"
                )

                result = subprocess.run(
                    ["java", "-jar", str(self.jar_path)] + args,
                    check=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    encoding="cp1251",
                    errors="replace",
                )

                if not result.stdout:
                    self.logger.warning("Пустой вывод от команды")
                    continue

                self.logger.debug(
                    f"Получен вывод команды (первые 200 символов): {result.stdout[:200]}..."
                )

                (
                    current_result,
                    current_unavailable,
                    current_success,
                    current_no_update,
                ) = self._parse_output(result.stdout)

                self.logger.debug(
                    f"Результат парсинга: nodes={len(current_result)}, unavailable={len(current_unavailable)}, "
                    f"success={len(current_success)}, no_update={len(current_no_update)}"
                )

                result_dict.update(current_result)
                unavailable_nodes.update(current_unavailable)
                success_nodes.update(current_success)
                no_update_needed_nodes.update(current_no_update)

                if not current_unavailable or max_retries <= 1:
                    self.logger.debug(
                        "Нет недоступных узлов или max_retries <= 1, завершаем попытки"
                    )
                    break

                if attempt < max_retries:
                    self.logger.debug(
                        f"Ожидание {self.config.get("wait_between_retries")} секунд перед следующей попыткой"
                    )
                    time.sleep(self.config.get("wait_between_retries"))

            except subprocess.CalledProcessError as e:
                error_msg = e.stderr if e.stderr else str(e)
                self.logger.error(f"Ошибка выполнения команды: {error_msg}")
                if attempt == max_retries or max_retries <= 1:
                    self.logger.error(
                        "Достигнуто максимальное количество попыток, возвращаем ошибку"
                    )
                    return {"error": {"message": error_msg}}
                continue
            except Exception as e:
                self.logger.error(f"Неожиданная ошибка: {str(e)}", exc_info=True)
                if attempt == max_retries or max_retries <= 1:
                    self.logger.error(
                        "Достигнуто максимальное количество попыток, возвращаем ошибку"
                    )
                    return {"error": {"message": str(e)}}
                continue

        # Заполнение недоступных узлов
        for node in unavailable_nodes:
            self.logger.debug(f"Добавление недоступного узла: {node}")
            result_dict[node] = {
                "tp": node,
                "type": None,
                "cv": None,
                "pv": None,
                "online": None,
                "status": "UNAVAILABLE",
                "ip": None,
                "ut": None,
                "local patches": None,
            }

        # Заполнение успешных узлов
        for node in success_nodes:
            if node not in result_dict:
                self.logger.debug(f"Добавление успешного узла: {node}")
                result_dict[node] = {
                    "tp": node,
                    "status": "SUCCESS",
                    "message": "успешно запланировано",
                    "type": None,
                    "cv": None,
                    "pv": None,
                    "online": None,
                    "ip": None,
                    "ut": None,
                    "local patches": None,
                }

        # Заполнение узлов, не требующих обновления
        for node in no_update_needed_nodes:
            if node not in result_dict:
                self.logger.debug(f"Добавление узла, не требующего обновления: {node}")
                result_dict[node] = {
                    "tp": node,
                    "status": "NO_UPDATE_NEEDED",
                    "message": f"Обновление узла {node} не требуется",
                    "type": None,
                    "cv": None,
                    "pv": None,
                    "online": None,
                    "ip": None,
                    "ut": None,
                    "local patches": None,
                }

        self.node_result = result_dict
        self.logger.debug("Вызов _categorize_nodes для классификации узлов")
        self._categorize_nodes()

        self.logger.info(
            f"Команда выполнена. Всего узлов: {len(result_dict)}, "
            f"успешных: {len(success_nodes)}, недоступных: {len(unavailable_nodes)}, "
            f"не требующих обновления: {len(no_update_needed_nodes)}"
        )

        return self.node_result

    def _parse_output(
        self, output: str
    ) -> Tuple[Dict[str, Dict[str, Optional[str]]], Set[str], Set[str], Set[str]]:
        """Парсим весь вывод stdout из JAR"""
        self.logger.debug("Начало парсинга вывода команды")

        if not output:
            self.logger.warning("Пустой вывод для парсинга")
            return {}, set(), set(), set()

        devices_dict: Dict[str, Dict[str, Optional[str]]] = {}
        unavailable_nodes: Set[str] = set()
        success_nodes: Set[str] = set()
        no_update_needed_nodes: Set[str] = set()

        try:
            self.logger.debug("Парсинг строк вывода для статусов обновления")
            for line in output.splitlines():
                line = line.strip()
                self.logger.debug(f"Обработка строки: {line}")

                # Обработка успешных узлов
                if "успешно запланировано" in line:
                    self.logger.debug(f"Найдена строка успешного обновления: {line}")
                    for part in line.split():
                        if (
                            part.replace(".", "").isdigit()
                            and len(part.split(".")) >= 3
                        ):
                            self.logger.debug(f"Добавление успешного узла: {part}")
                            success_nodes.add(part)
                            devices_dict[part] = {
                                "tp": part,
                                "status": "SUCCESS",
                                "message": f"Обновление узла {part} успешно запланировано",
                                "type": None,
                                "cv": None,
                                "pv": None,
                                "online": None,
                                "ip": None,
                                "ut": None,
                                "local patches": None,
                            }

                # Обработка недоступных узлов
                elif "недоступен" in line:
                    self.logger.debug(f"Найдена строка недоступного узла: {line}")
                    for part in line.split():
                        if (
                            part.replace(".", "").isdigit()
                            and len(part.split(".")) >= 3
                        ):
                            self.logger.debug(f"Добавление недоступного узла: {part}")
                            unavailable_nodes.add(part)
                            devices_dict[part] = {
                                "tp": part,
                                "status": "UNAVAILABLE",
                                "message": f"Узел {part} недоступен",
                                "type": None,
                                "cv": None,
                                "pv": None,
                                "online": None,
                                "ip": None,
                                "ut": None,
                                "local patches": None,
                            }

                # Обработка узлов, не требующих обновления
                elif "не требуется" in line:
                    self.logger.debug(
                        f"Найдена строка узла, не требующего обновления: {line}"
                    )
                    for part in line.split():
                        if (
                            part.replace(".", "").isdigit()
                            and len(part.split(".")) >= 3
                        ):
                            self.logger.debug(
                                f"Добавление узла, не требующего обновления: {part}"
                            )
                            no_update_needed_nodes.add(part)
                            devices_dict[part] = {
                                "tp": part,
                                "status": "NO_UPDATE_NEEDED",
                                "message": f"Обновление узла {part} не требуется",
                                "type": None,
                                "cv": None,
                                "pv": None,
                                "online": None,
                                "ip": None,
                                "ut": None,
                                "local patches": None,
                            }

            self.logger.debug("Парсинг строк вывода для детальной информации об узлах")
            for line in output.splitlines():
                line = line.strip()
                self.logger.debug(f"Обработка строки данных: {line}")

                if not line or line.startswith(("Current client version:", "-")):
                    continue

                device: Dict[str, Optional[str]] = {}
                device_key = None
                tp_value = None

                # Разбор по символу ";"
                for pair in line.split(";"):
                    pair = pair.strip()
                    if "=" in pair:
                        key, value = pair.split("=", 1)
                        key = key.strip()
                        value = (
                            value.strip() if value.strip().lower() != "null" else None
                        )
                        device[key] = value

                        if key == "ip" and value:
                            device_key = value
                        elif key == "tp" and value:
                            tp_value = value
                            if not device_key:
                                device_key = value

                if not device_key and tp_value:
                    device_key = tp_value

                if device and device_key:
                    self.logger.debug(
                        f"Добавление/обновление узла {device_key}: {device}"
                    )
                    devices_dict[device_key] = device

                    status = (device.get("status") or "").upper()
                    online = (device.get("online") or "").upper()

                    if status == "UNAVAILABLE" or online == "FALSE" or online == "NO":
                        self.logger.debug(
                            f"Узел {device_key} недоступен (status={status}, online={online})"
                        )
                        unavailable_nodes.add(device_key)

        except Exception as e:
            self.logger.error(f"Ошибка при парсинге вывода: {str(e)}", exc_info=True)
            return {}, set(), set(), set()

        self.logger.info(
            f"Парсинг завершен. Узлов: {len(devices_dict)}, "
            f"недоступных: {len(unavailable_nodes)}, "
            f"успешных: {len(success_nodes)}, "
            f"не требующих обновления: {len(no_update_needed_nodes)}"
        )

        return devices_dict, unavailable_nodes, success_nodes, no_update_needed_nodes

    def _categorize_nodes(self):
        """Категоризация узлов по статусам"""
        self.logger.debug("Начало категоризации узлов по статусам")

        self.work_tp = []
        self.error_tp = []
        self.update_tp = []
        self.ccm_tp = []
        self.unzip_tp = []
        self.no_update_needed_tp = []
        self.unavailable = []

        for node_id, node_data in self.node_result.items():
            status = (node_data.get("status") or "").upper()
            node_type = (node_data.get("type") or "").strip()
            ip_node = (node_data.get("ip") or "").strip()
            tp = node_data.get("tp") or node_id
            version = (node_data.get("cv") or "").strip()

            self.logger.debug(
                f"Обработка узла {node_id} (tp={tp}, status={status}, type={node_type}, version={version})"
            )

            if tp.split(".")[3] == "0":
                tp = tp.split(".")[2]
            else:
                tp = f"{tp.split('.')[2]}.{tp.split('.')[3]}"

            list_entry = f"{tp}"
            if node_type:
                list_entry += f"-{node_type}"
            if ip_node:
                list_entry += f"-{ip_node}"
            if version:
                list_entry += f"-{version}"

            self.logger.debug(f"Формирование записи для списка: {list_entry}")

            if status == "IN_WORK":
                self.work_tp.append(list_entry)
                self.logger.debug(f"Добавлен в work_tp: {list_entry}")
            elif status in ("UPGRADE_ERROR_WITH_DOWNGRADE", "FAST_REVERT"):
                self.error_tp.append(list_entry)
                self.logger.debug(f"Добавлен в error_tp: {list_entry}")
            elif status in (
                "UPGRADE_PLANING",
                "UPGRADE_DOWNLOADING",
                "UPGRADE_WAIT_FOR_REBOOT",
                "CHECK_PERMISSIONS",
                "BACKUP",
                "APPLY_PATCH",
                "TEST_START",
            ):
                self.update_tp.append(list_entry)
                self.logger.debug(f"Добавлен в update_tp: {list_entry}")
            elif status == "CCM_UPDATE_RESTART":
                self.ccm_tp.append(list_entry)
                self.logger.debug(f"Добавлен в ccm_tp: {list_entry}")
            elif status == "UNZIP_FILES":
                self.unzip_tp.append(list_entry)
                self.logger.debug(f"Добавлен в unzip_tp: {list_entry}")
            elif status == "NO_UPDATE_NEEDED":
                self.no_update_needed_tp.append(list_entry)
                self.logger.debug(f"Добавлен в no_update_needed_tp: {list_entry}")
            elif status == "UNAVAILABLE":
                self.unavailable.append(list_entry)
                self.logger.debug(f"Добавлен в unavailable: {list_entry}")

        self.logger.info(
            f"Категоризация завершена. work_tp: {len(self.work_tp)}, "
            f"error_tp: {len(self.error_tp)}, update_tp: {len(self.update_tp)}, "
            f"ccm_tp: {len(self.ccm_tp)}, unzip_tp: {len(self.unzip_tp)}, "
            f"no_update_needed_tp: {len(self.no_update_needed_tp)}, "
            f"unavailable: {len(self.unavailable)}"
        )

    def save_status_lists(self, prefix: str = ""):
        """Сохраняет все списки статусов в отдельные файлы"""
        self.logger.debug(f"Сохранение списков статусов с префиксом '{prefix}'")

        lists_to_save = {
            self.config.get("files.work_tp"): self.work_tp,
            self.config.get("files.error_tp"): self.error_tp,
            self.config.get("files.update_tp"): self.update_tp,
            self.config.get("files.ccm_tp"): self.ccm_tp,
            self.config.get("files.unzip_tp"): self.unzip_tp,
            self.config.get("files.no_update_needed_tp"): self.no_update_needed_tp,
            self.config.get("files.unavailable_tp"): self.unavailable,
        }

        for orig_name, data in lists_to_save.items():
            # берём только имя файла, без каталогов
            base_name = Path(orig_name).name
            target_path = self.config.get("config_dir") / f"{prefix}{base_name}"
            # удалить старый
            if target_path.exists():
                target_path.unlink()
            # записать новый
            if data:  # список не пуст
                target_path.write_text("\n".join(data), encoding="utf-8")
                self.logger.info("Записан %s (%d строк)", target_path, len(data))
            else:
                self.logger.debug("Список %s пуст – файл не создаётся", base_name)

    def get_all_nodes(
        self, max_retries: int = MAX_RETRIES_DEFAULT
    ) -> Dict[str, Dict[str, Optional[str]]]:
        """Получить состояние всех узлов с Centrum по частям из файла node_list.txt или из БД"""

        # Определяем источник данных
        node_list_path = self.config.get_full_path("node_list")
        use_database = not node_list_path.exists()

        if use_database:
            self.logger.info(
                "Файл node_list.txt не найден. Получение данных из базы PostgreSQL"
            )

            # Получаем данные из БД
            db_result = self._get_nodes_from_database()
            if "error" in db_result:
                self.logger.error(
                    f"Ошибка получения данных из БД: {db_result['error']}"
                )
                return db_result

            self.logger.info(f"Получено {len(db_result)} узлов из базы данных")

            # Сохраняем результат и возвращаем
            self.node_result = db_result
            return db_result

        else:
            self.logger.info(
                "Получение состояния всех узлов с Centrum из файла node_list.txt"
            )

            # Существующая логика для работы с файлом
            # Читаем все номера серверов
            with open(node_list_path, "r", encoding="utf-8") as f:
                all_nodes = [line.strip() for line in f if line.strip()]

            if not all_nodes:
                self.logger.warning("Файл node_list.txt пуст")
                return {}

            self.logger.info(f"Найдено {len(all_nodes)} узлов в файле node_list.txt")

            # Разбиваем на группы по 10 серверов
            all_results: Dict[str, Dict[str, Optional[str]]] = {}
            chunk_size = 10

            for i in range(0, len(all_nodes), chunk_size):
                chunk = all_nodes[i : i + chunk_size]
                self.logger.info(
                    f"Обработка группы {i//chunk_size + 1}/{(len(all_nodes)-1)//chunk_size + 1}: {chunk}"
                )

                # Записываем текущую группу в server.txt
                server_list_path = self.config.get_full_path("server_list")
                with open(server_list_path, "w", encoding="utf-8") as f:
                    f.write("\n".join(chunk))

                # Получаем состояние для текущей группы
                for _ in range(max_retries):
                    chunk_result = self.get_nodes_from_file()

                    # Проверяем на ошибки
                    if "error" in chunk_result:
                        self.logger.error(
                            f"Ошибка при получении состояния для группы {chunk}: {chunk_result['error']}"
                        )
                        # Продолжаем с следующей группой, но записываем ошибку
                        for node in chunk:
                            all_results[node] = {
                                "tp": node,
                                "status": "ERROR",
                                "message": f"Ошибка получения состояния: {chunk_result['error'].get('message', 'Unknown error')}",
                                "type": None,
                                "cv": None,
                                "pv": None,
                                "online": None,
                                "ip": None,
                                "ut": None,
                                "local patches": None,
                            }
                    else:
                        # Добавляем результаты текущей группы
                        all_results.update(chunk_result)

                # Пауза 3 секунды между группами
                if i + chunk_size < len(all_nodes):  # Не ждем после последней группы
                    self.logger.info("Ожидание 3 секунды перед следующей группой...")
                    time.sleep(3)

            # Фильтрация по типу (аналогично БД)
            all_results = {
                ip: node_data
                for ip, node_data in all_results.items()
                if node_data.get("type") is not None
            }

            self.logger.info(
                f"Все группы обработаны. Всего получено состояний: {len(all_results)}"
            )

            # Сохраняем объединенный результат
            self.node_result = all_results
            return all_results

    def get_nodes_from_file(self, filename: Optional[Union[Path, str]] = None) -> Dict:
        """Пример метода с использованием конфигурации"""
        if filename is None:
            filename = self.config.get_full_path("server_list")

        filepath = Path(self.config.get("config_dir")) / filename
        self.logger.info(f"Получение состояния узлов из файла {filepath}")
        return self._execute_command(
            ["-ch", self.centrum_host, "-f", str(filepath)],
            MAX_RETRIES_SINGLE,
        )

    def update_servers(
        self,
        version_sv: str = None,
        filename: Union[Path, None] = None,
        no_backup: bool = DEFAULT_NO_BACKUP,
    ) -> Dict[str, Dict[str, Optional[str]]]:
        """Запустить обновление серверов список которых перечислены в файле"""
        if version_sv is None:
            version_sv = self.target_version
        if filename is None:
            filename = Path(self.config.get("files.server_list"))
        filepath = self.config.get("config_dir") / filename

        self.logger.info(
            f"Запуск обновления серверов из файла {filepath} до версии {version_sv}"
        )

        args = ["-ch", self.centrum_host, "-f", str(filepath), "-sv", version_sv]
        if no_backup:
            args.append("-nb")
            self.logger.debug("Используется флаг no_backup (-nb)")

        return self._execute_command(args, MAX_RETRIES_SINGLE)

    def save_node_result(self, filename: Union[Path, None] = None):
        """Сохранить результат в файл"""
        if filename is None:
            filename = Path(self.config.get("node_result"))
        filepath = self.config.get("config_dir") / filename

        self.logger.info(f"Сохранение результатов в файл {filepath}")

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.node_result, f, ensure_ascii=False, indent=2)
        self.logger.info(
            f"Результат сохранен в {filepath} (узлов: {len(self.node_result)})"
        )

    def extract_tp_index(self, tp: str) -> str:
        """Извлекает индекс из tp формата '1.0.индекс.0'"""
        self.logger.debug(f"Извлечение индекса из tp: {tp}")
        parts = tp.split(".")
        if len(parts) >= 3:
            if parts[3] == "0":
                result = parts[2]
            else:
                result = f"{parts[2]}.{parts[3]}"
            self.logger.debug(f"Извлеченный индекс: {result}")
            return result
        self.logger.debug(
            f"Не удалось извлечь индекс, возвращаем исходное значение: {tp}"
        )
        return tp

    def get_retail_servers_to_update(self, all_nodes: Dict) -> List[Dict]:
        """Получает список серверов RETAIL, которые нужно обновить"""
        self.logger.info("Поиск серверов RETAIL для обновления")
        servers_to_update = []

        for ip, node_data in all_nodes.items():
            node_type = node_data.get("type")
            current_version = node_data.get("cv")
            tp = node_data.get("tp", "")

            self.logger.debug(
                f"Проверка узла {ip} (type={node_type}, version={current_version}, tp={tp})"
            )

            if (
                node_type == "RETAIL"
                and current_version != self.target_version
                and ip not in self.updated_servers
            ):
                tp_index = self.extract_tp_index(tp)
                server_info = {
                    "ip": ip,
                    "tp": tp,
                    "current_version": current_version,
                    "tp_index": tp_index,
                }
                self.logger.debug(f"Добавление сервера для обновления: {server_info}")
                servers_to_update.append(server_info)

        self.logger.info(f"Найдено серверов для обновления: {len(servers_to_update)}")
        return servers_to_update

    def create_server_file(
        self, servers: List[Dict], filename: Union[Path, None] = None
    ) -> None:
        """Создает файл server.txt с индексами серверов"""
        if filename is None:
            filename = Path(self.config.get("server_list"))
        filepath = self.config.get("config_dir") / filename

        self.logger.info(f"Создание файла {filepath} с {len(servers)} серверами")

        with open(filepath, "w", encoding="utf-8") as f:
            for server in servers:
                f.write(f"{server['tp_index']}\n")
                self.logger.debug(f"Запись сервера в файл: {server['tp_index']}")

        self.logger.info(f"Файл {filename} успешно создан")

    def check_file_exists(self, filename: str) -> bool:
        """Проверяет существование файла"""
        filepath = self.config.get("config_dir") / filename
        exists = filepath.exists() and filepath.stat().st_size > 0
        self.logger.debug(f"Проверка файла {filename}: exists={exists}")
        return exists

    def read_file_lines(self, filename: str) -> List[str]:
        """Читает строки из файла, игнорируя строки с индексом '0'"""
        filepath = self.config.get("config_dir") / filename
        if not filepath.exists():
            self.logger.warning(f"Файл {filename} не существует")
            return []

        self.logger.debug(f"Чтение строк из файла {filename} (игнорируя индекс '0')")
        valid_lines = []

        with open(filepath, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue  # Пропускаем пустые строки

                # Разбиваем строку по первому "-" для проверки индекса
                parts = line.split("-", 1)
                if parts[0] == "0":
                    self.logger.debug(f"Игнорируем строку с индексом '0': {line}")
                    continue

                valid_lines.append(line)

        self.logger.debug(f"Прочитано строк (без '0'): {len(valid_lines)}")
        return valid_lines

    def command_with_plink(self, servers: List[str], restart_file: str) -> bool:
        """Перезапускает службу на серверах используя PLINK"""
        self.logger.info(f"Начало обработки {len(servers)} серверов")
        try:
            # Проверяем наличие необходимых файлов
            command_filepath = Path(restart_file)
            self.logger.debug(f"Проверка существования файла команд: {command_filepath}")

            if not command_filepath.exists():
                self.logger.error(f"Файл команд {restart_file} не найден")
                return False
            else:
                self.logger.debug("Файл команд найден")

            self.logger.debug(
                f"Проверка существования plink: {self.config.get("plink_path")}"
            )
            if not self.config.get("plink_path").exists():
                self.logger.error("plink.exe не найден")
                return False
            else:
                self.logger.debug("plink.exe найден")

            # Обрабатываем каждый сервер
            failed_servers = []
            for server_info in servers:
                self.logger.info(f"Обработка сервера: {server_info}")

                # Извлекаем IP из формата "индекс-тип-ip-версия"
                parts = server_info.split("-")
                if len(parts) < 3:
                    self.logger.error(f"Неверный формат строки сервера: {server_info}")
                    failed_servers.append(server_info)
                    continue

                server_ip = parts[2]
                server_index = parts[0]
                self.logger.debug(
                    f"Извлеченные данные: ip={server_ip}, index={server_index}"
                )

                # Проверяем доступность через ping

                self.logger.debug(f"Проверка доступности {server_ip} через ping")
                if not self._check_ping(server_ip):
                    self.logger.warning(
                        f"Сервер {server_ip} (индекс {server_index}) недоступен по ping"
                    )
                    failed_servers.append(server_info)
                    continue
                else:
                    self.logger.debug("Сервер доступен по ping")

                # Выполняем команды через plink
                cmd = [
                    str(self.config.get("plink_path")),
                    "-ssh",
                    f"{self.config.get("ssh_user")}@{server_ip}",
                    "-pw",
                    self.password,
                    "-batch",
                    "-m",
                    str(command_filepath),
                ]
                self.logger.debug(f"Команда для выполнения: {' '.join(cmd)}")

                try:
                    self.logger.info(f"Запуск команд на сервере {server_ip}")

                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        timeout=self.config.get("plink_timeout"),
                        encoding="cp1251",
                    )

                    if result.returncode == 0:
                        self.logger.info(f"Команды успешно выполнены на {server_ip}")
                        if result.stdout:
                            self.logger.debug(f"Вывод команды:\n{result.stdout}")
                    else:
                        self.logger.error(
                            f"Ошибка выполнения на {server_ip}:\nКод возврата: {result.returncode}\nОшибка: {result.stderr}"
                        )
                        failed_servers.append(server_info)

                except subprocess.TimeoutExpired:
                    self.logger.error(
                        f"Таймаут выполнения команд на {server_ip} (превышено {self.config.get("plink_timeout")} сек)"
                    )
                    failed_servers.append(server_info)
                except Exception as e:
                    self.logger.error(
                        f"Неожиданная ошибка при работе с {server_ip}: {str(e)}",
                        exc_info=True,
                    )
                    failed_servers.append(server_info)

                # Пауза между серверами
                self.logger.debug("Пауза 2 секунды перед следующим сервером")
                time.sleep(2)

            # Итоговая проверка
            if failed_servers:
                self.logger.error(
                    f"Не удалось обработать {len(failed_servers)} серверов: {failed_servers}"
                )
                return False
            else:
                self.logger.info("Все серверы успешно обработаны")
                return True

        except Exception as e:
            self.logger.error(
                f"Критическая ошибка в command_with_plink: {str(e)}",
                exc_info=True,
            )
            return False

    def _check_ping(self, host: str) -> bool:
        """Проверка доступности хоста через ping"""
        self.logger.debug(f"Выполнение ping для {host}")
        try:
            result = subprocess.run(
                ["ping", "-n", "1", "-w", str(self.config.get("ping_timeout")), host],
                capture_output=True,
                text=True,
            )
            if "TTL=" in result.stdout:
                self.logger.debug(f"Ping успешен для {host}")
                return True
            else:
                self.logger.debug(f"Ping не удался для {host}")
                return False
        except Exception as e:
            self.logger.error(f"Ошибка при выполнении ping для {host}: {str(e)}")
            return False

    def compare_servers_and_versions(
        self, work_servers: List[str], original_servers: List[Dict]
    ) -> tuple[bool, List[str]]:
        """Сравнивает серверы из work_tp с исходными и проверяет версии"""
        self.logger.info("Сравнение серверов и версий")

        # 3. Игнорируем строки с индексом 0
        original_indices = {
            server["tp_index"]
            for server in original_servers
            # if server["tp_index"] != "0"
        }

        work_indices = set()
        incorrect_versions = []

        for server_info in work_servers:
            parts = server_info.split("-")
            if len(parts) >= 1:
                tp_index = parts[0]
                # Пропускаем серверы с индексом 0
                if tp_index == "0":
                    self.logger.debug(f"Игнорируем сервер с индексом 0: {server_info}")
                    continue

                work_indices.add(tp_index)
                self.logger.debug(f"Индекс из work_tp: {tp_index}")

                # Проверяем версию, если есть информация о версии в строке
                if len(parts) >= 4:
                    server_version = parts[3]
                    if server_version != self.target_version:
                        self.logger.warning(f"Неверная версия у сервера {server_info}")
                        incorrect_versions.append(server_info)

        self.logger.debug(f"Оригинальные индексы: {original_indices}")
        self.logger.debug(f"Индексы из work_tp (без 0): {work_indices}")

        if original_indices != work_indices:
            self.logger.error(
                f"Несоответствие серверов: ожидалось {original_indices}, получено {work_indices}"
            )
            return False, incorrect_versions

        if incorrect_versions:
            self.logger.error(f"Серверы с неправильными версиями: {incorrect_versions}")
            return False, incorrect_versions

        self.logger.info(
            "Все серверы соответствуют ожидаемым и имеют правильные версии"
        )
        return True, []

    def _perform_pre_work(self):
        """Выполняет предварительные работы с сервером перед обновлением"""
        self.logger.info("Выполнение предварительных работ с сервером")
        work_servers = self.read_file_lines(self.config.get("work_tp"))
        if work_servers:
            self.logger.info(f"Предварительные работы на серверах: {work_servers}")
            if not self.command_with_plink(
                work_servers, self.config.get("pre_update_commands")
            ):
                self.logger.error("Ошибка выполнения предварительных работ")
                return False
        self.logger.info(f"Ожидание {self.config.get("pre_update_timeout")} секунд...")
        time.sleep(self.config.get("pre_update_timeout"))
        return True

    def _perform_post_work(self):
        """Выполняет дополнительные работы с сервером после обновления"""
        self.logger.info("Выполнение дополнительных работ с сервером после обновления")
        work_servers = self.read_file_lines(self.config.get("work_tp"))
        if work_servers:
            self.logger.info(f"Дополнительные работы на серверах: {work_servers}")
            if not self.command_with_plink(
                work_servers, self.config.get("post_update_commands")
            ):
                self.logger.error("Ошибка выполнения дополнительных работ")
                return False
        self.logger.info(f"Ожидание {self.config.get("post_update_timeout")} секунд...")
        time.sleep(self.config.get("post_update_timeout"))
        return True

    def _monitor_update_status(self, current_part_server: List[Dict]) -> bool:
        """Мониторит статус обновления для текущей итерации"""
        while True:
            self.logger.info(
                f"Ожидание {self.config.get("status_check_interval") // 60} минут перед проверкой..."
            )
            time.sleep(self.config.get("status_check_interval"))

            # Получаем статус только для текущей итерации
            self.get_nodes_from_file()
            self.save_status_lists(prefix=self.config.get("status_prefix"))

            # Проверяем ошибки
            if self._check_errors():
                return False

            # Проверяем статусы обновления
            status_check = self._check_update_statuses(current_part_server)
            if status_check is not None:  # None означает продолжение ожидания
                return status_check

    def _check_errors(self) -> bool:
        """Проверяет наличие ошибок обновления"""
        if self.check_file_exists(
            self.config.get("status_prefix") + self.config.get("error_tp")
        ):
            error_servers = self.read_file_lines(
                self.config.get("status_prefix") + self.config.get("error_tp")
            )
            self.logger.error(f"Ошибки обновления на серверах: {error_servers}")
            return True
        return False

    def _check_update_statuses(self, current_part_server: List[Dict]) -> Optional[bool]:
        """Проверяет различные статусы обновления"""
        # Проверяем необходимость перезапуска служб
        if self._handle_service_restart(
            self.config.get("ccm_tp"), self.config.get("ccm_restart_commands")
        ):
            return None
        if self._handle_service_restart(
            self.config.get("unzip_tp"), self.config.get("unzip_restart_commands")
        ):
            return None

        # Обработка статуса update_tp (обновление в процессе)
        if self.check_file_exists(
            self.config.get("status_prefix") + self.config.get("update_tp")
        ):
            current_update_servers = set(
                self.read_file_lines(
                    self.config.get("status_prefix") + self.config.get("update_tp")
                )
            )
            if not hasattr(self, "_update_servers_prev"):
                # Первое обнаружение - сохраняем и продолжаем ожидание
                self._update_servers_prev = current_update_servers
                self._update_servers_counter = 1
                self.logger.debug(
                    f"Обновление в процессе для серверов: {current_update_servers}"
                )
                return None
            elif current_update_servers == self._update_servers_prev:
                # Те же серверы в статусе update_tp
                self._update_servers_counter += 1
                if (
                    self._update_servers_counter >= 2
                ):  # Допускаем 1 повтора (2 проверки)
                    self.logger.error(
                        f"Серверы слишком долго в статусе обновления: {current_update_servers} (попытка {self._update_servers_counter})"
                    )
                    return False  # Считаем это ошибкой
                self.logger.warning(
                    f"Обновление затянулось для серверов: {current_update_servers} (попытка {self._update_servers_counter})"
                )
                return None
            else:
                # Изменился список серверов в update_tp - сбрасываем счетчик
                self._update_servers_prev = current_update_servers
                self._update_servers_counter = 1
                self.logger.debug(
                    f"Прогресс обновления: новые серверы в процессе - {current_update_servers}"
                )
                return None

        # Обработка статуса unavailable (недоступные серверы)
        if self.check_file_exists(
            self.config.get("status_prefix") + self.config.get("unavailable_tp")
        ):
            current_unavailable_servers = set(
                self.read_file_lines(
                    self.config.get("status_prefix") + self.config.get("unavailable_tp")
                )
            )

            if not hasattr(self, "_unavailable_servers_prev"):
                # Первое обнаружение - сохраняем и продолжаем ожидание
                self._unavailable_servers_prev = current_unavailable_servers
                self._unavailable_servers_counter = 1
                self.logger.warning(
                    f"Обнаружены недоступные серверы: {current_unavailable_servers}"
                )
                return None
            elif current_unavailable_servers == self._unavailable_servers_prev:
                # Те же серверы остаются недоступными
                self._unavailable_servers_counter += 1
                if self._unavailable_servers_counter >= 2:
                    self.logger.error(
                        f"Серверы остаются недоступными: {current_unavailable_servers} (попытка {self._unavailable_servers_counter})"
                    )
                    return False
            else:
                # Изменился список недоступных серверов - сбрасываем счетчик
                self._unavailable_servers_prev = current_unavailable_servers
                self._unavailable_servers_counter = 1
                self.logger.warning(
                    f"Изменение списка недоступных серверов: {current_unavailable_servers}"
                )
                return None

        # Проверяем завершение обновления
        if self.check_file_exists(
            self.config.get("status_prefix") + self.config.get("work_tp")
        ):
            work_servers = self.read_file_lines(
                self.config.get("status_prefix") + self.config.get("work_tp")
            )
            servers_match, incorrect_versions = self.compare_servers_and_versions(
                work_servers, current_part_server
            )
            if servers_match and not incorrect_versions:
                # Сбрасываем счетчики при успешном завершении
                if hasattr(self, "_update_servers_prev"):
                    del self._update_servers_prev
                    del self._update_servers_counter
                if hasattr(self, "_unavailable_servers_prev"):
                    del self._unavailable_servers_prev
                    del self._unavailable_servers_counter
                return True

        return None

    def _handle_service_restart(self, status_file: str, commands_file: str) -> bool:
        """Обрабатывает перезапуск служб при необходимости"""
        if self.check_file_exists(self.config.get("status_prefix") + status_file):
            servers = self.read_file_lines(
                self.config.get("status_prefix") + status_file
            )
            self.logger.info(f"Перезапуск служб на серверах: {servers}")
            if not self.command_with_plink(servers, commands_file):
                self.logger.error(f"Ошибка перезапуска служб ({status_file})")
                return False
            return True
        return False

    def update_servers_part_server(self) -> bool:
        """Основной метод обновления серверов по частям с сохранением состояния"""
        self.logger.info("Начало пошагового обновления серверов")

        # Получаем все узлы один раз в начале
        self.logger.debug("Первоначальное получение списка всех узлов")
        initial_nodes = self.get_all_nodes(max_retries=MAX_RETRIES_DEFAULT)
        if "error" in initial_nodes:
            self.logger.error(f"Ошибка получения узлов: {initial_nodes['error']}")
            return False

        # Инициализируем node_result с исходными данными
        self.node_result = initial_nodes
        self.save_node_result()

        # Создаем копию для локальной работы, чтобы не перезаписывать node_result
        current_nodes_state = initial_nodes.copy()

        while True:
            if self.config.get(
                "max_iterations"
            ) and self.current_iteration >= self.config.get("max_iterations"):
                self.logger.info(
                    f"Достигнуто максимальное количество итераций ({self.config.get("max_iterations")})"
                )
                return True

            self.logger.info(f"Итерация {self.current_iteration + 1}")

            # Используем актуальное состояние узлов
            servers_to_update = self.get_retail_servers_to_update(current_nodes_state)

            if not servers_to_update:
                self.logger.info("Все серверы RETAIL уже обновлены до целевой версии")
                return True

            current_part_server = servers_to_update[
                : self.config.get("part_server_size")
            ]
            self.current_iteration += 1

            self.logger.info(
                f"Обработка итерации: {[s['tp_index'] for s in current_part_server]}"
            )

            # Создаем временный файл для текущей итерации
            self.create_server_file(current_part_server)

            # Получаем статус только для текущей итерации (не перезаписываем основной словарь)
            self.logger.debug("Получение статуса серверов перед обновлением")
            part_server_nodes = self.get_nodes_from_file()
            self.save_status_lists()

            # Предварительные работы(например копирование файлов обновления)
            if self.config.get("pre_update_work"):
                if not self._perform_pre_work():
                    return False

            # Запускаем обновление
            self.logger.info(f"Запуск обновления до версии {self.target_version}")
            update_result = self.update_servers(version_sv=self.target_version)
            if "error" in update_result:
                self.logger.error(f"Ошибка обновления: {update_result['error']}")
                return False

            # Мониторим статус обновления
            if not self._monitor_update_status(current_part_server):
                return False

            # Обновляем состояние только для успешно обновленных узлов
            for server in current_part_server:
                ip = server["ip"]
                if ip in current_nodes_state:
                    current_nodes_state[ip]["cv"] = self.target_version
                    self.updated_servers.add(ip)
                    self.logger.debug(
                        f"Обновлена версия для {ip} -> {self.target_version}"
                    )

            # Синхронизируем с основным словарем и сохраняем
            self.node_result.update(current_nodes_state)
            self.save_node_result()

            # Предварительные работы(например копирование файлов обновления)
            if self.config.get("post_update_work"):
                if not self._perform_post_work():
                    return False

            # Удаляем временный файл с серверами текущей итерации
            server_file = self.config.get("config_dir") / self.config.get("server_list")
            if server_file.exists():
                server_file.unlink()
                self.logger.debug(f"Удален временный файл {server_file}")

            # Продолжаем цикл для следующего итерации
