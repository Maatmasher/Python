# main.py
from config_manager import ConfigManager
from unified_server_updater import UnifiedServerUpdater


def main():
    try:
        # Способ 1: Конфигурация по умолчанию
        config = ConfigManager()
        updater = UnifiedServerUpdater(config)

        # Способ 2: Загрузка из файла
        # config = ConfigManager("config.json")
        # updater = UnifiedServerUpdater(config)

        # Способ 3: Динамическое изменение конфигурации
        # config.set("target_version", "10.4.18.0")
        # config.set("part_server_size", 3)

        # Запуск процесса обновления
        success = updater.update_servers_part_server()

        if success:
            updater.logger.info("Обновление завершено успешно")
        else:
            updater.logger.error("Обновление завершено с ошибками")

    except Exception as e:
        # Используем базовый print для критических ошибок инициализации
        print(f"Критическая ошибка инициализации: {e}")
        raise


if __name__ == "__main__":
    main()
